var maindata = [
                {"id":1,"vcEventAffect":'MantoEye v1.0版本发布',"dtRecordTime":'2010-08-23'},
                {"id":2,"vcEventAffect":'MantoEye v2.0版本发布',"dtRecordTime":'2010-10-12'}
                ];